﻿namespace _2д_игра
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form8));
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            label9 = new Label();
            pictureBox9 = new PictureBox();
            label8 = new Label();
            pictureBox8 = new PictureBox();
            label7 = new Label();
            pictureBox7 = new PictureBox();
            label6 = new Label();
            pictureBox6 = new PictureBox();
            label5 = new Label();
            pictureBox4 = new PictureBox();
            label4 = new Label();
            pictureBox3 = new PictureBox();
            label3 = new Label();
            pictureBox2 = new PictureBox();
            label2 = new Label();
            label1 = new Label();
            menuStrip1 = new MenuStrip();
            вернутьсяВМенюToolStripMenuItem = new ToolStripMenuItem();
            оПерсонажейToolStripMenuItem = new ToolStripMenuItem();
            оПерсонажей2СтрToolStripMenuItem = new ToolStripMenuItem();
            pictureBox5 = new PictureBox();
            pictureBox10 = new PictureBox();
            label10 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(800, 450);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(192, 255, 255);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(pictureBox10);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(pictureBox9);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(pictureBox8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(pictureBox7);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(pictureBox6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(menuStrip1);
            panel1.Location = new Point(12, 29);
            panel1.Name = "panel1";
            panel1.Size = new Size(776, 393);
            panel1.TabIndex = 2;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(563, 210);
            label9.Name = "label9";
            label9.Size = new Size(138, 90);
            label9.TabIndex = 18;
            label9.Text = "Враг 3: сносит по 2 xp\r\nбыстро бегает  но \r\nможет тебя не заметить\r\nвыско прыгает\r\nу него корона но это не\r\n значит что он кароль";
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(487, 215);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(59, 55);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 17;
            pictureBox9.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(563, 137);
            label8.Name = "label8";
            label8.Size = new Size(127, 60);
            label8.TabIndex = 16;
            label8.Text = "Враг 2: сносит по 2 xp\r\nс**а котороя летает\r\nи мешает проходить\r\nвидет тебя из далека";
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(485, 142);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(59, 55);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 15;
            pictureBox8.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(552, 67);
            label7.Name = "label7";
            label7.Size = new Size(129, 45);
            label7.TabIndex = 14;
            label7.Text = "Враг 1: сносит по 2 xp\r\nпроходит через стены\r\nно тупой";
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(485, 67);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(59, 55);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 13;
            pictureBox7.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(91, 316);
            label6.Name = "label6";
            label6.Size = new Size(250, 45);
            label6.TabIndex = 12;
            label6.Text = "Морская свинка : не знаю почему она тут ??\r\n но может она что то знает??????\r\nпопробуй найди ее";
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(17, 321);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(59, 55);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 11;
            pictureBox6.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(91, 245);
            label5.Name = "label5";
            label5.Size = new Size(317, 60);
            label5.TabIndex = 10;
            label5.Text = "Просто чел : можно поболтать   \r\nего можно найти проходя уровни нажав левойкнопкой \r\nмыши ты болатаешь\r\n\r\n";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(17, 245);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(59, 55);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 9;
            pictureBox4.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(91, 155);
            label4.Name = "label4";
            label4.Size = new Size(325, 75);
            label4.TabIndex = 8;
            label4.Text = resources.GetString("label4.Text");
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(17, 155);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(59, 55);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 7;
            pictureBox3.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(91, 89);
            label3.Name = "label3";
            label3.Size = new Size(235, 45);
            label3.TabIndex = 6;
            label3.Text = "Игрок-это ты . Ты лубишь приключения \r\n,и ищешь БОССА!!!! не знаю почиму  но \r\nв этом мире это очень круто\r\n";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(17, 83);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(59, 55);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label2.Location = new Point(17, 43);
            label2.Name = "label2";
            label2.Size = new Size(105, 21);
            label2.TabIndex = 2;
            label2.Text = "О песонажей";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.Location = new Point(331, 34);
            label1.Name = "label1";
            label1.Size = new Size(138, 30);
            label1.TabIndex = 1;
            label1.Text = "НАСТРОЙКИ";
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = Color.FromArgb(128, 64, 64);
            menuStrip1.Items.AddRange(new ToolStripItem[] { вернутьсяВМенюToolStripMenuItem, оПерсонажейToolStripMenuItem, оПерсонажей2СтрToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(776, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // вернутьсяВМенюToolStripMenuItem
            // 
            вернутьсяВМенюToolStripMenuItem.Name = "вернутьсяВМенюToolStripMenuItem";
            вернутьсяВМенюToolStripMenuItem.Size = new Size(119, 20);
            вернутьсяВМенюToolStripMenuItem.Text = "Вернуться в меню";
            вернутьсяВМенюToolStripMenuItem.Click += вернутьсяВМенюToolStripMenuItem_Click;
            // 
            // оПерсонажейToolStripMenuItem
            // 
            оПерсонажейToolStripMenuItem.Name = "оПерсонажейToolStripMenuItem";
            оПерсонажейToolStripMenuItem.Size = new Size(86, 20);
            оПерсонажейToolStripMenuItem.Text = "Упровление";
            оПерсонажейToolStripMenuItem.Click += оПерсонажейToolStripMenuItem_Click;
            // 
            // оПерсонажей2СтрToolStripMenuItem
            // 
            оПерсонажей2СтрToolStripMenuItem.Name = "оПерсонажей2СтрToolStripMenuItem";
            оПерсонажей2СтрToolStripMenuItem.Size = new Size(129, 20);
            оПерсонажей2СтрToolStripMenuItem.Text = "О персонажей 2 стр";
            оПерсонажей2СтрToolStripMenuItem.Click += оПерсонажей2СтрToolStripMenuItem_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.Location = new Point(-62, 350);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(100, 50);
            pictureBox5.TabIndex = 7;
            pictureBox5.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(487, 316);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(59, 55);
            pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 19;
            pictureBox10.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(563, 321);
            label10.Name = "label10";
            label10.Size = new Size(175, 30);
            label10.TabIndex = 20;
            label10.Text = "БОМЖ ВАЛЕРА  отнимает 2 хп\r\nбыстро бегает  любит бухать";
            // 
            // Form8
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBox5);
            Name = "Form8";
            Text = "Form8";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private Panel panel1;
        private Label label3;
        private PictureBox pictureBox2;
        private Label label2;
        private Label label1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem вернутьсяВМенюToolStripMenuItem;
        private ToolStripMenuItem оПерсонажейToolStripMenuItem;
        private PictureBox pictureBox5;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private Label label4;
        private Label label5;
        private PictureBox pictureBox7;
        private Label label6;
        private PictureBox pictureBox6;
        private Label label9;
        private PictureBox pictureBox9;
        private Label label8;
        private PictureBox pictureBox8;
        private Label label7;
        private ToolStripMenuItem оПерсонажей2СтрToolStripMenuItem;
        private Label label10;
        private PictureBox pictureBox10;
    }
}