﻿namespace _2д_игра
{
    partial class Form14
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form14));
            pictureBox1 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox12 = new PictureBox();
            pictureBox9 = new PictureBox();
            pictureBox10 = new PictureBox();
            pictureBox25 = new PictureBox();
            pictureBox14 = new PictureBox();
            pictureBox11 = new PictureBox();
            pictureBox13 = new PictureBox();
            pictureBox15 = new PictureBox();
            pictureBox16 = new PictureBox();
            label1 = new Label();
            labelCoins = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox25).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(800, 450);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.SeaGreen;
            pictureBox4.Location = new Point(0, 400);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(800, 50);
            pictureBox4.TabIndex = 17;
            pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.SeaGreen;
            pictureBox2.Location = new Point(0, 288);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(204, 50);
            pictureBox2.TabIndex = 18;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.SeaGreen;
            pictureBox3.Location = new Point(293, 288);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(204, 50);
            pictureBox3.TabIndex = 19;
            pictureBox3.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.SeaGreen;
            pictureBox5.Location = new Point(596, 288);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(204, 50);
            pictureBox5.TabIndex = 20;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = Color.SeaGreen;
            pictureBox6.Location = new Point(316, 143);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(149, 50);
            pictureBox6.TabIndex = 21;
            pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.SeaGreen;
            pictureBox7.Location = new Point(0, 143);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(204, 50);
            pictureBox7.TabIndex = 22;
            pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = Color.SeaGreen;
            pictureBox8.Location = new Point(605, 143);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(204, 50);
            pictureBox8.TabIndex = 23;
            pictureBox8.TabStop = false;
            // 
            // pictureBox12
            // 
            pictureBox12.BackColor = SystemColors.ActiveCaptionText;
            pictureBox12.Location = new Point(0, 217);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(47, 71);
            pictureBox12.TabIndex = 51;
            pictureBox12.TabStop = false;
            // 
            // pictureBox9
            // 
            pictureBox9.BackColor = SystemColors.ActiveCaptionText;
            pictureBox9.Location = new Point(753, 217);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(47, 71);
            pictureBox9.TabIndex = 52;
            pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.BackColor = Color.Goldenrod;
            pictureBox10.Location = new Point(367, 72);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(47, 71);
            pictureBox10.TabIndex = 53;
            pictureBox10.TabStop = false;
            // 
            // pictureBox25
            // 
            pictureBox25.Image = (Image)resources.GetObject("pictureBox25.Image");
            pictureBox25.Location = new Point(95, 237);
            pictureBox25.Name = "pictureBox25";
            pictureBox25.Size = new Size(50, 51);
            pictureBox25.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox25.TabIndex = 63;
            pictureBox25.TabStop = false;
            // 
            // pictureBox14
            // 
            pictureBox14.Image = (Image)resources.GetObject("pictureBox14.Image");
            pictureBox14.Location = new Point(50, 105);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(36, 38);
            pictureBox14.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox14.TabIndex = 66;
            pictureBox14.TabStop = false;
            // 
            // pictureBox11
            // 
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(414, 250);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(36, 38);
            pictureBox11.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox11.TabIndex = 67;
            pictureBox11.TabStop = false;
            // 
            // pictureBox13
            // 
            pictureBox13.Image = (Image)resources.GetObject("pictureBox13.Image");
            pictureBox13.Location = new Point(50, 357);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(44, 43);
            pictureBox13.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox13.TabIndex = 68;
            pictureBox13.TabStop = false;
            // 
            // pictureBox15
            // 
            pictureBox15.Image = (Image)resources.GetObject("pictureBox15.Image");
            pictureBox15.Location = new Point(619, 105);
            pictureBox15.Name = "pictureBox15";
            pictureBox15.Size = new Size(44, 43);
            pictureBox15.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox15.TabIndex = 69;
            pictureBox15.TabStop = false;
            // 
            // pictureBox16
            // 
            pictureBox16.Image = (Image)resources.GetObject("pictureBox16.Image");
            pictureBox16.Location = new Point(650, 357);
            pictureBox16.Name = "pictureBox16";
            pictureBox16.Size = new Size(44, 43);
            pictureBox16.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox16.TabIndex = 70;
            pictureBox16.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 72;
            label1.Text = "label1";
            // 
            // labelCoins
            // 
            labelCoins.AutoSize = true;
            labelCoins.Location = new Point(12, 43);
            labelCoins.Name = "labelCoins";
            labelCoins.Size = new Size(76, 15);
            labelCoins.TabIndex = 73;
            labelCoins.Text = "Монеты: 100";
            // 
            // Form14
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(labelCoins);
            Controls.Add(label1);
            Controls.Add(pictureBox16);
            Controls.Add(pictureBox15);
            Controls.Add(pictureBox13);
            Controls.Add(pictureBox11);
            Controls.Add(pictureBox14);
            Controls.Add(pictureBox25);
            Controls.Add(pictureBox10);
            Controls.Add(pictureBox9);
            Controls.Add(pictureBox12);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox1);
            Name = "Form14";
            Text = "Form14";
            KeyDown += Form14_KeyDown;
            KeyUp += Form14_KeyUp;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox25).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox4;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private PictureBox pictureBox12;
        private PictureBox pictureBox9;
        private PictureBox pictureBox10;
        private PictureBox pictureBox25;
        private PictureBox pictureBox14;
        private PictureBox pictureBox11;
        private PictureBox pictureBox13;
        private PictureBox pictureBox15;
        private PictureBox pictureBox16;
        private Label label1;
        private Label labelCoins;
        private System.Windows.Forms.Timer timer1;
    }
}