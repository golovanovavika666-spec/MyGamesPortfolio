﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2д_игра
{
    public partial class Form4 : Form
    {

        // Управление движением
        bool goLeft, goRight, jumping;
        int jumpSpeed = 20;
        int jumpSpeedCurrent;
        int gravity = 10;
        bool isOnGround;
        Point playerStartPoint;
        int lives = 5; // количество жизней
        Label livesLabel = new Label(); // лейбл для отображения жизней
        List<PictureBox> spikes = new List<PictureBox>(); // список шипов
        List<PictureBox> enemies = new List<PictureBox>();
        List<int> enemySpeedY = new List<int>();

        System.Windows.Forms.Timer gameTimer = new System.Windows.Forms.Timer();
        public Form4()
        {
            InitializeComponent();
            playerStartPoint = pictureBox11.Location;

            // Настраиваем таймер
            gameTimer.Interval = 20; // 20 мс - примерно 50 кадров в секунду
            gameTimer.Tick += gameTimer_Tick;
            gameTimer.Start();

            this.KeyDown += Form4_KeyDown;
            this.KeyUp += Form4_KeyUp;

            // Устанавливаем Tag "platform" для земли (8 платформ)
            pictureBox2.Tag = "platform";
            pictureBox3.Tag = "platform";
            pictureBox4.Tag = "platform";
            pictureBox5.Tag = "platform";
            pictureBox6.Tag = "platform";
            pictureBox7.Tag = "platform";
            pictureBox8.Tag = "platform";
            pictureBox9.Tag = "platform";
            pictureBox10.Tag = "platform";
            pictureBox11.Tag = "platform";
            pictureBox12.Tag = "nextLevel";
            pictureBox13.Tag = "exitScared";


            // Лейбл для жизней
            label1.Text = "Жизни: " + lives;
            livesLabel.Font = new Font("Arial", 14, FontStyle.Bold);
            livesLabel.ForeColor = Color.Red;
            livesLabel.BackColor = Color.Transparent;
            livesLabel.AutoSize = true;
            livesLabel.Location = new Point(10, 10);
            this.Controls.Add(livesLabel);

            // Назначаем шипам тег и добавляем их в список
            pictureBox14.Tag = "spike";
            pictureBox15.Tag = "spike";
            pictureBox16.Tag = "spike";

            spikes.Add(pictureBox14);
            spikes.Add(pictureBox15);
            spikes.Add(pictureBox16);

            // Важно: на форме у тебя уже должны быть добавлены pictureBox1..pictureBox11
            // 11 - игрок

            // === Инициализация врагов ===
            enemies.Add(pictureBox18);
            enemies.Add(pictureBox19);
            enemies.Add(pictureBox20);
            // Изначально скорость всех врагов по Y = 0
            enemySpeedY.Add(0);
            enemySpeedY.Add(0);
            enemySpeedY.Add(0);

            // Устанавливаем теги для врагов (для читаемости)
            pictureBox18.Tag = "enemy";
            pictureBox19.Tag = "enemy";
            pictureBox20.Tag = "enemy";


        }



        private void gameTimer_Tick(object sender, EventArgs e)
        {
            // Движение влево-вправо
            if (goLeft)
                pictureBox17.Left -= 7;
            if (goRight)
                pictureBox17.Left += 7;

            // Прыжок или падение
            if (jumping)
            {
                // Прыжок вверх
                pictureBox17.Top -= jumpSpeedCurrent;
                jumpSpeedCurrent -= 1; // уменьшение скорости прыжка (гравитация)
                if (jumpSpeedCurrent < 0)
                    jumping = false; // начинается падение после пика прыжка
            }
            else
            {
                // Падение вниз (гравитация)
                pictureBox17.Top += gravity;
            }



            for (int i = 0; i < enemies.Count; i++)
            {
                PictureBox enemy = enemies[i];
                int dx = pictureBox17.Left - enemy.Left;
                int dy = pictureBox17.Top - enemy.Top;

                // Если игрок рядом по горизонтали
                if (Math.Abs(dx) < 200)
                {
                    enemy.Left += Math.Sign(dx) * 2; // враг двигается к игроку
                }

                // Прыгает, если игрок выше
                if (dy < -20 && Math.Abs(dx) < 100)
                {
                    enemySpeedY[i] = -15; // прыжок вверх
                }

                // Применяем гравитацию
                enemySpeedY[i] += 1;
                enemy.Top += enemySpeedY[i];

                // Проверка столкновений врага с платформами
                foreach (Control x in this.Controls)
                {
                    if (x is PictureBox && x.Tag != null && x.Tag.ToString() == "platform")
                    {
                        if (enemy.Bounds.IntersectsWith(x.Bounds) &&
                            enemy.Bottom >= x.Top && enemy.Top < x.Top)
                        {
                            enemy.Top = x.Top - enemy.Height;
                            enemySpeedY[i] = 0; // сбрасываем скорость по Y
                        }
                    }
                }

                // Границы формы
                if (enemy.Left < 0) enemy.Left = 0;
                if (enemy.Right > ClientSize.Width) enemy.Left = ClientSize.Width - enemy.Width;
                if (enemy.Top < 0) enemy.Top = 0;
                if (enemy.Bottom > ClientSize.Height)
                {
                    enemy.Top = ClientSize.Height - enemy.Height;
                    enemySpeedY[i] = 0;
                }

                // Урон игроку при касании
                if (enemy.Bounds.IntersectsWith(pictureBox17.Bounds))
                {
                    lives -= 2;
                    livesLabel.Text = "Жизни: " + lives;
                    pictureBox17.Location = playerStartPoint;

                    if (lives <= 0)
                    {
                        gameTimer.Stop();
                        MessageBox.Show("Вы проиграли! Жизней не осталось.");
                        Form1 menu = new Form1();
                        menu.Show();
                        this.Close();
                    }
                }
            }


            foreach (PictureBox spike in spikes)
            {
                if (pictureBox17.Bounds.IntersectsWith(spike.Bounds))
                {
                    lives--;
                    label1.Text = "Жизни: " + lives;
                    pictureBox17.Location = playerStartPoint;

                    if (lives <= 0)
                    {
                        gameTimer.Stop();
                        MessageBox.Show("Вы проиграли! Жизней не осталось.");
                        Form1 menu = new Form1();
                        menu.Show();
                        this.Close();
                    }

                    break; // чтобы жизнь не снялась несколько раз за один тик
                }
            }

            // Проверка перехода на следующий уровень
            if (pictureBox17.Bounds.IntersectsWith(pictureBox12.Bounds))
            {
                gameTimer.Stop(); // Останавливаем таймер
                DialogResult result = MessageBox.Show(
                    "Вы дошли до конца уровня! Что дальше?",
                    "Выбор",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    this.Hide();
                    Form5 form5 = new Form5();
                    form5.Show();
                }
                else if (result == DialogResult.No)
                {
                    // Вернуться в меню
                    Form1 menu = new Form1();
                    menu.Show();
                    this.Close();
                }
            }

            // Проверка выхода в страхе
            if (pictureBox17.Bounds.IntersectsWith(pictureBox13.Bounds))
            {
                gameTimer.Stop(); // Останавливаем таймер
                DialogResult result = MessageBox.Show(
                    "Вы испугались и ушли. Вернуться в меню?",
                    "Страх",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);

                if (result == DialogResult.OK)
                {
                    Form1 menu = new Form1();
                    menu.Show();
                    this.Close();
                }
            }

            // После обновления позиции игрока добавим ограничения по экрану

            // Левая граница
            if (pictureBox17.Left < 0)
                pictureBox17.Left = 0;

            // Правая граница (ширина формы минус ширина игрока)
            if (pictureBox17.Right > this.ClientSize.Width)
                pictureBox17.Left = this.ClientSize.Width - pictureBox17.Width;

            // Верхняя граница (чтобы игрок не уходил слишком высоко)
            if (pictureBox17.Top < 0)
            {
                pictureBox17.Top = 0;
                jumpSpeedCurrent = 0;
                jumping = false;
            }

            // Нижняя граница (например, пол формы или можно сделать игровое падение)
            if (pictureBox17.Bottom > this.ClientSize.Height)
            {
                pictureBox17.Top = this.ClientSize.Height - pictureBox17.Height;
                isOnGround = true;
                jumping = false;
                jumpSpeedCurrent = 0;
            }

            isOnGround = false;

            // Проверка столкновений с платформами
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && x.Tag != null && x.Tag.ToString() == "platform")
                {
                    // Проверяем, пересекается ли игрок с платформой
                    if (pictureBox17.Bounds.IntersectsWith(x.Bounds))
                    {
                        // Если игрок падает вниз (не прыгает)
                        if (!jumping && pictureBox17.Bottom <= x.Top + (gravity + 5))
                        {
                            // Устанавливаем игрока на платформу
                            pictureBox17.Top = x.Top - pictureBox17.Height;
                            isOnGround = true;
                            jumpSpeedCurrent = 0;
                        }
                        // Если игрок прыгает и касается платформы снизу (например, ударился головой)
                        else if (jumping && pictureBox17.Top < x.Bottom && pictureBox17.Bottom > x.Bottom)
                        {
                            jumpSpeedCurrent = 0;
                            jumping = false;
                            // Можно установить позицию игрока ниже платформы (чтобы не застрял в ней)
                            pictureBox17.Top = x.Bottom;
                        }
                    }
                }
            }
        }
        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void Form4_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.A)
                goLeft = false;
            if (e.KeyCode == Keys.Right || e.KeyCode == Keys.D)
                goRight = false;
        }

        private void Form4_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.A)
                goLeft = true;
            if (e.KeyCode == Keys.Right || e.KeyCode == Keys.D)
                goRight = true;

            if ((e.KeyCode == Keys.Up || e.KeyCode == Keys.W || e.KeyCode == Keys.Space) && isOnGround)
            {
                jumping = true;
                jumpSpeedCurrent = jumpSpeed;
            }
        }
    }
}
