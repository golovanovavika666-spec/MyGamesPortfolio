﻿namespace _2д_игра
{
    partial class Form9
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form9));
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            label6 = new Label();
            pictureBox3 = new PictureBox();
            label5 = new Label();
            pictureBox11 = new PictureBox();
            label4 = new Label();
            pictureBox2 = new PictureBox();
            pictureBox14 = new PictureBox();
            label9 = new Label();
            pictureBox9 = new PictureBox();
            label8 = new Label();
            pictureBox8 = new PictureBox();
            label7 = new Label();
            pictureBox7 = new PictureBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            menuStrip1 = new MenuStrip();
            вернутьсяВМенюToolStripMenuItem = new ToolStripMenuItem();
            оПерсонажейToolStripMenuItem = new ToolStripMenuItem();
            оПерсонажей2СтрToolStripMenuItem = new ToolStripMenuItem();
            pictureBox10 = new PictureBox();
            label10 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(800, 450);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(192, 255, 255);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(pictureBox10);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(pictureBox11);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(pictureBox14);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(pictureBox9);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(pictureBox8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(pictureBox7);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(menuStrip1);
            panel1.Location = new Point(12, 29);
            panel1.Name = "panel1";
            panel1.Size = new Size(776, 393);
            panel1.TabIndex = 3;
            panel1.Paint += panel1_Paint;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(92, 313);
            label6.Name = "label6";
            label6.Size = new Size(120, 60);
            label6.TabIndex = 35;
            label6.Text = "Турель: Серьезно ?! \r\n страно как бутоки \r\nона из какойто игры\r\n\r\n";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(17, 313);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(59, 55);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 34;
            pictureBox3.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(92, 245);
            label5.Name = "label5";
            label5.Size = new Size(153, 45);
            label5.TabIndex = 33;
            label5.Text = "Шипы : могут отлкивать и \r\nотнимаю 1хр\r\nбуть аккуратен";
            // 
            // pictureBox11
            // 
            pictureBox11.BackColor = SystemColors.AppWorkspace;
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(17, 260);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(53, 20);
            pictureBox11.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox11.TabIndex = 32;
            pictureBox11.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(83, 177);
            label4.Name = "label4";
            label4.Size = new Size(234, 30);
            label4.TabIndex = 31;
            label4.Text = "Золотая дверь .Интересно куда она ведет\r\n??????????????";
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.Goldenrod;
            pictureBox2.Location = new Point(17, 167);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(47, 71);
            pictureBox2.TabIndex = 30;
            pictureBox2.TabStop = false;
            // 
            // pictureBox14
            // 
            pictureBox14.BackColor = SystemColors.ActiveCaptionText;
            pictureBox14.Location = new Point(17, 83);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(47, 71);
            pictureBox14.TabIndex = 29;
            pictureBox14.TabStop = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(550, 228);
            label9.Name = "label9";
            label9.Size = new Size(194, 75);
            label9.TabIndex = 18;
            label9.Text = " Энергетик энерджи: появляеться \r\nпо прохождению уровней\r\n дает по 3 жизни чтоб \r\nвыпить нажми на <R>\r\n\r\n";
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(425, 228);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(89, 70);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 17;
            pictureBox9.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(550, 162);
            label8.Name = "label8";
            label8.Size = new Size(176, 60);
            label8.TabIndex = 16;
            label8.Text = "БООООООООООССССССССС\r\n?????????????????????????????????\r\n????????????????????????????????\r\n\r\n";
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(425, 144);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(104, 78);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 15;
            pictureBox8.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(550, 89);
            label7.Name = "label7";
            label7.Size = new Size(226, 45);
            label7.TabIndex = 14;
            label7.Text = "Лавка торговца\r\nтам какието челики\r\nможно что то купить там есть торговиц";
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(425, 83);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(104, 55);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 13;
            pictureBox7.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(83, 93);
            label3.Name = "label3";
            label3.Size = new Size(242, 45);
            label3.TabIndex = 6;
            label3.Text = "дверь есть 2 двери одна идет на следущий \r\nуровнь другая идет на главное меню\r\nтипо ты испугался и ушол";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label2.Location = new Point(17, 43);
            label2.Name = "label2";
            label2.Size = new Size(145, 21);
            label2.TabIndex = 2;
            label2.Text = "О песонажей 2 стр";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.Location = new Point(331, 34);
            label1.Name = "label1";
            label1.Size = new Size(138, 30);
            label1.TabIndex = 1;
            label1.Text = "НАСТРОЙКИ";
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = Color.FromArgb(128, 64, 64);
            menuStrip1.Items.AddRange(new ToolStripItem[] { вернутьсяВМенюToolStripMenuItem, оПерсонажейToolStripMenuItem, оПерсонажей2СтрToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(776, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // вернутьсяВМенюToolStripMenuItem
            // 
            вернутьсяВМенюToolStripMenuItem.Name = "вернутьсяВМенюToolStripMenuItem";
            вернутьсяВМенюToolStripMenuItem.Size = new Size(119, 20);
            вернутьсяВМенюToolStripMenuItem.Text = "Вернуться в меню";
            вернутьсяВМенюToolStripMenuItem.Click += вернутьсяВМенюToolStripMenuItem_Click;
            // 
            // оПерсонажейToolStripMenuItem
            // 
            оПерсонажейToolStripMenuItem.Name = "оПерсонажейToolStripMenuItem";
            оПерсонажейToolStripMenuItem.Size = new Size(86, 20);
            оПерсонажейToolStripMenuItem.Text = "Упровление";
            оПерсонажейToolStripMenuItem.Click += оПерсонажейToolStripMenuItem_Click;
            // 
            // оПерсонажей2СтрToolStripMenuItem
            // 
            оПерсонажей2СтрToolStripMenuItem.Name = "оПерсонажей2СтрToolStripMenuItem";
            оПерсонажей2СтрToolStripMenuItem.Size = new Size(102, 20);
            оПерсонажей2СтрToolStripMenuItem.Text = "О персонажей ";
            оПерсонажей2СтрToolStripMenuItem.Click += оПерсонажей2СтрToolStripMenuItem_Click;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(437, 313);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(59, 55);
            pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 36;
            pictureBox10.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(518, 313);
            label10.Name = "label10";
            label10.Size = new Size(192, 45);
            label10.TabIndex = 37;
            label10.Text = "Миленький монстр отнимает 2хр\r\nочень милый но быстрый  \r\nмимимиимиимими";
            // 
            // Form9
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            Controls.Add(pictureBox1);
            Name = "Form9";
            Text = "Form9";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private Panel panel1;
        private Label label9;
        private PictureBox pictureBox9;
        private Label label8;
        private PictureBox pictureBox8;
        private Label label7;
        private PictureBox pictureBox7;
        private Label label3;
        private Label label2;
        private Label label1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem вернутьсяВМенюToolStripMenuItem;
        private ToolStripMenuItem оПерсонажейToolStripMenuItem;
        private ToolStripMenuItem оПерсонажей2СтрToolStripMenuItem;
        private PictureBox pictureBox14;
        private Label label4;
        private PictureBox pictureBox2;
        private Label label5;
        private PictureBox pictureBox11;
        private Label label6;
        private PictureBox pictureBox3;
        private Label label10;
        private PictureBox pictureBox10;
    }
}