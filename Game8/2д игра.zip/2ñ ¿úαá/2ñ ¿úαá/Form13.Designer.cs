﻿namespace _2д_игра
{
    partial class Form13
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form13));
            pictureBox1 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox12 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox25 = new PictureBox();
            pictureBox11 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox14 = new PictureBox();
            label1 = new Label();
            labelCoins = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox25).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(800, 450);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.OliveDrab;
            pictureBox7.Location = new Point(0, 395);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(800, 55);
            pictureBox7.TabIndex = 13;
            pictureBox7.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.OliveDrab;
            pictureBox2.Location = new Point(149, 344);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(651, 55);
            pictureBox2.TabIndex = 14;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.OliveDrab;
            pictureBox3.Location = new Point(417, 216);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(393, 131);
            pictureBox3.TabIndex = 15;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.OliveDrab;
            pictureBox4.Location = new Point(0, 89);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(444, 35);
            pictureBox4.TabIndex = 16;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.OliveDrab;
            pictureBox5.Location = new Point(0, 216);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(276, 36);
            pictureBox5.TabIndex = 17;
            pictureBox5.TabStop = false;
            // 
            // pictureBox12
            // 
            pictureBox12.BackColor = SystemColors.ActiveCaptionText;
            pictureBox12.Location = new Point(0, 19);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(47, 71);
            pictureBox12.TabIndex = 50;
            pictureBox12.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = SystemColors.ActiveCaptionText;
            pictureBox6.Location = new Point(0, 328);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(47, 71);
            pictureBox6.TabIndex = 51;
            pictureBox6.TabStop = false;
            // 
            // pictureBox25
            // 
            pictureBox25.Image = (Image)resources.GetObject("pictureBox25.Image");
            pictureBox25.Location = new Point(114, 32);
            pictureBox25.Name = "pictureBox25";
            pictureBox25.Size = new Size(50, 51);
            pictureBox25.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox25.TabIndex = 62;
            pictureBox25.TabStop = false;
            // 
            // pictureBox11
            // 
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(684, 173);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(44, 43);
            pictureBox11.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox11.TabIndex = 63;
            pictureBox11.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(53, 173);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(44, 43);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 64;
            pictureBox8.TabStop = false;
            // 
            // pictureBox14
            // 
            pictureBox14.Image = (Image)resources.GetObject("pictureBox14.Image");
            pictureBox14.Location = new Point(217, 178);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(36, 38);
            pictureBox14.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox14.TabIndex = 65;
            pictureBox14.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(702, 9);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 66;
            label1.Text = "label1";
            // 
            // labelCoins
            // 
            labelCoins.AutoSize = true;
            labelCoins.Location = new Point(702, 39);
            labelCoins.Name = "labelCoins";
            labelCoins.Size = new Size(76, 15);
            labelCoins.TabIndex = 67;
            labelCoins.Text = "Монеты: 100";
            // 
            // Form13
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(labelCoins);
            Controls.Add(label1);
            Controls.Add(pictureBox14);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox11);
            Controls.Add(pictureBox25);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox12);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox1);
            Name = "Form13";
            Text = "Form13";
            KeyDown += Form13_KeyDown;
            KeyUp += Form13_KeyUp;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox25).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox7;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox12;
        private PictureBox pictureBox6;
        private PictureBox pictureBox25;
        private PictureBox pictureBox11;
        private PictureBox pictureBox8;
        private PictureBox pictureBox14;
        private Label label1;
        private Label labelCoins;
        private System.Windows.Forms.Timer timer1;
    }
}