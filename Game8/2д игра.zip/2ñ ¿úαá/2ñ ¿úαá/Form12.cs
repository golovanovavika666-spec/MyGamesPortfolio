﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2д_игра
{
    public partial class Form12 : Form
    {


        // Управление движением
        bool goLeft, goRight, jumping;
        int jumpSpeed = 20;
        int jumpSpeedCurrent;
        int gravity = 10;
        bool isOnGround;


        List<int> enemyDirection = new List<int>(); // -1 = влево, 1 = вправо
        Point playerStartPoint;
        int lives = 5; // количество жизней
        Label livesLabel = new Label(); // лейбл для отображения жизней
        List<PictureBox> spikes = new List<PictureBox>(); // список шипов
        List<PictureBox> enemies = new List<PictureBox>();
        List<int> enemySpeedY = new List<int>();

        System.Windows.Forms.Timer gameTimer = new System.Windows.Forms.Timer();
        public Form12()
        {
            InitializeComponent();


            playerStartPoint = pictureBox11.Location;

            // Настраиваем таймер
            gameTimer.Interval = 20; // 20 мс - примерно 50 кадров в секунду
            gameTimer.Tick += gameTimer_Tick;
            gameTimer.Start();

            this.KeyDown += Form12_KeyDown;
            this.KeyUp += Form12_KeyUp;

            // Устанавливаем Tag "platform" для земли (8 платформ)
            pictureBox2.Tag = "platform";
            pictureBox3.Tag = "platform";
            pictureBox4.Tag = "platform";
            pictureBox5.Tag = "platform";
            pictureBox6.Tag = "platform";
            pictureBox7.Tag = "platform";
            pictureBox8.Tag = "platform";
            pictureBox9.Tag = "platform";
            pictureBox10.Tag = "platform";


            pictureBox12.Tag = "nextLevel";
            pictureBox13.Tag = "exitScared";


            enemyDirection.Add(1); // Враг 1 идет вправо
            enemyDirection.Add(-1); // Враг 2 идет влево
            enemyDirection.Add(1); // Враг 3 идет вправо

            // Лейбл для жизней
            label1.Text = "Жизни: " + lives;
            livesLabel.Font = new Font("Arial", 14, FontStyle.Bold);
            livesLabel.ForeColor = Color.Red;
            livesLabel.BackColor = Color.Transparent;
            livesLabel.AutoSize = true;
            livesLabel.Location = new Point(10, 10);
            this.Controls.Add(livesLabel);

            // Назначаем шипам тег и добавляем их в список
            pictureBox17.Tag = "spike";
            pictureBox20.Tag = "spike";
            pictureBox21.Tag = "spike";
            pictureBox22.Tag = "spike";
            pictureBox23.Tag = "spike";
            pictureBox24.Tag = "spike";


            spikes.Add(pictureBox17);
            spikes.Add(pictureBox20);
            spikes.Add(pictureBox21);
            spikes.Add(pictureBox22);
            spikes.Add(pictureBox23);
            spikes.Add(pictureBox24);



            lives--;
            UpdateLivesLabels();

            // Важно: на форме у тебя уже должны быть добавлены pictureBox1..pictureBox11
            // 11 - игрок

            // === Инициализация врагов ===
            enemies.Add(pictureBox15);
            enemies.Add(pictureBox11);
            // Изначально скорость всех врагов по Y = 0
            enemySpeedY.Add(0);
            enemySpeedY.Add(0);
            enemySpeedY.Add(0);

            // Устанавливаем теги для врагов (для читаемости)
            pictureBox11.Tag = "enemy";
            pictureBox15.Tag = "enemy";
        }


        private void UpdateLivesLabels()
        {
            livesLabel.Text = "Жизни: " + lives;
            label1.Text = "Жизни: " + lives;
        }


        private void gameTimer_Tick(object sender, EventArgs e)
        {
            // Движение влево-вправо
            if (goLeft)
                pictureBox25.Left -= 7;
            if (goRight)
                pictureBox25.Left += 7;

            // Прыжок или падение
            if (jumping)
            {
                // Прыжок вверх
                pictureBox25.Top -= jumpSpeedCurrent;
                jumpSpeedCurrent -= 1; // уменьшение скорости прыжка (гравитация)
                if (jumpSpeedCurrent < 0)
                    jumping = false; // начинается падение после пика прыжка
            }
            else
            {
                // Падение вниз (гравитация)
                pictureBox25.Top += gravity;
            }




            for (int i = 0; i < enemies.Count; i++)
            {
                PictureBox enemy = enemies[i];
                int dx = pictureBox25.Left - enemy.Left;
                int dy = pictureBox25.Top - enemy.Top;

                // Враг двигается к игроку, только если:
                // - Игрок на одной высоте (разница по Y не больше 30 пикселей)
                // - И в радиусе 200 по X
                if (Math.Abs(dx) < 200 && Math.Abs(dy) < 30)
                {
                    int followSpeed = 1;
                    enemy.Left += Math.Sign(dx) * followSpeed;
                }

                // Патрулирование
                enemy.Left += enemyDirection[i] * 2;

                // Разворот при границах
                bool needToTurn = false;

                if (enemy.Left < 0 || enemy.Right > ClientSize.Width)
                    needToTurn = true;

                // Проверка на платформу под врагом
                bool onPlatform = false;
                foreach (Control x in this.Controls)
                {
                    if (x is PictureBox && x.Tag != null && x.Tag.ToString() == "platform")
                    {
                        Rectangle platformRect = x.Bounds;
                        Rectangle underEnemy = new Rectangle(enemy.Left, enemy.Bottom + 1, enemy.Width, 2);

                        if (underEnemy.IntersectsWith(platformRect))
                        {
                            onPlatform = true;
                            break;
                        }
                    }
                }

                if (Math.Abs(dx) < 200 && Math.Abs(dy) < 100)
                {
                    bool hasPlatformBetween = false;

                    foreach (Control ctrl in this.Controls)
                    {
                        if (ctrl is PictureBox && ctrl.Tag != null && ctrl.Tag.ToString() == "platform")
                        {
                            Rectangle platformRect = ctrl.Bounds;

                            // Проверка, есть ли платформа между врагом и игроком по вертикали
                            if (platformRect.Top > Math.Min(pictureBox25.Bottom, enemy.Bottom) &&
                                platformRect.Bottom < Math.Max(pictureBox25.Top, enemy.Top) &&
                                platformRect.Right > Math.Min(pictureBox25.Right, enemy.Right) &&
                                platformRect.Left < Math.Max(pictureBox25.Left, enemy.Left))
                            {
                                hasPlatformBetween = true;
                                break;
                            }
                        }
                    }

                    if (!hasPlatformBetween && Math.Abs(dy) < 30)
                    {
                        int followSpeed = 1;
                        enemy.Left += Math.Sign(dx) * followSpeed;
                    }
                }

                if (!onPlatform)
                    needToTurn = true;

                if (needToTurn)
                    enemyDirection[i] *= -1;

                // Гравитация
                enemySpeedY[i] += 1;
                enemy.Top += enemySpeedY[i];

                // Остальные проверки...
                // (можно оставить как есть из твоего цикла ниже)
            }



            // --- Добавляем проверку боковых столкновений с платформами ---
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && x.Tag != null && x.Tag.ToString() == "platform")
                {
                    if (pictureBox25.Bounds.IntersectsWith(x.Bounds))
                    {
                        Rectangle playerRect = pictureBox25.Bounds;
                        Rectangle platformRect = x.Bounds;

                        // Проверяем пересечение по горизонтали
                        if (playerRect.Right > platformRect.Left && playerRect.Left < platformRect.Left &&
                            playerRect.Bottom > platformRect.Top + 5 && playerRect.Top < platformRect.Bottom - 5)
                        {
                            // Столкновение справа от игрока (заходит в платформу слева)
                            pictureBox25.Left = platformRect.Left - pictureBox25.Width;
                        }
                        else if (playerRect.Left < platformRect.Right && playerRect.Right > platformRect.Right &&
                                 playerRect.Bottom > platformRect.Top + 5 && playerRect.Top < platformRect.Bottom - 5)
                        {
                            // Столкновение слева от игрока (заходит в платформу справа)
                            pictureBox25.Left = platformRect.Right;
                        }
                    }
                }
            }

            // Проверка подбора энергетиков
            if (pictureBox16.Visible && pictureBox16.Bounds.IntersectsWith(pictureBox25.Bounds))
            {
                pictureBox16.Visible = false;
                lives += 3;
                UpdateLivesLabels();  // Вызов вместо прямого обновления
            }


            if (pictureBox14.Visible && pictureBox14.Bounds.IntersectsWith(pictureBox25.Bounds))
            {
                pictureBox14.Visible = false;
                lives += 3;
                UpdateLivesLabels();  // Вызов вместо прямого обновления
            }

            for (int i = 0; i < enemies.Count; i++)
            {
                PictureBox enemy = enemies[i];
                int dx = pictureBox25.Left - enemy.Left;
                int dy = pictureBox25.Top - enemy.Top;





                // Применяем гравитацию
                enemySpeedY[i] += 1;
                enemy.Top += enemySpeedY[i];

                // Проверка столкновений врага с платформами
                foreach (Control x in this.Controls)
                {
                    if (x is PictureBox && x.Tag != null && x.Tag.ToString() == "platform")
                    {
                        if (enemy.Bounds.IntersectsWith(x.Bounds) &&
                            enemy.Bottom >= x.Top && enemy.Top < x.Top)
                        {
                            enemy.Top = x.Top - enemy.Height;
                            enemySpeedY[i] = 0; // сбрасываем скорость по Y
                        }
                    }
                }

                // Границы формы
                if (enemy.Left < 0) enemy.Left = 0;
                if (enemy.Right > ClientSize.Width) enemy.Left = ClientSize.Width - enemy.Width;
                if (enemy.Top < 0) enemy.Top = 0;
                if (enemy.Bottom > ClientSize.Height)
                {
                    enemy.Top = ClientSize.Height - enemy.Height;
                    enemySpeedY[i] = 0;
                }

                // Урон игроку при касании
                if (enemy.Bounds.IntersectsWith(pictureBox25.Bounds))
                {
                    lives -= 2;
                    UpdateLivesLabels();
                    pictureBox25.Location = playerStartPoint;

                    if (lives <= 0)
                    {
                        gameTimer.Stop();
                        MessageBox.Show("Вы проиграли! Жизней не осталось.");
                        Form1 menu = new Form1();
                        menu.Show();
                        this.Close();
                    }
                }
            }


            foreach (PictureBox spike in spikes)
            {
                if (pictureBox25.Bounds.IntersectsWith(spike.Bounds))
                {
                    lives--;
                    UpdateLivesLabels();
                    pictureBox25.Location = playerStartPoint;

                    if (lives <= 0)
                    {
                        gameTimer.Stop();
                        MessageBox.Show("Вы проиграли! Жизней не осталось.");
                        Form1 menu = new Form1();
                        menu.Show();
                        this.Close();
                    }

                    break; // чтобы жизнь не снялась несколько раз за один тик
                }
            }

            // Проверка перехода на следующий уровень
            if (pictureBox25.Bounds.IntersectsWith(pictureBox12.Bounds))
            {
                gameTimer.Stop(); // Останавливаем таймер
                DialogResult result = MessageBox.Show(
                    "Вы дошли до конца уровня! Что дальше?",
                    "Выбор",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    this.Hide();
                    Form13 form13 = new Form13();
                    form13.Show();
                }
                else if (result == DialogResult.No)
                {
                    // Вернуться в меню
                    Form1 menu = new Form1();
                    menu.Show();
                    this.Close();
                }
            }

            // Проверка выхода в страхе
            if (pictureBox25.Bounds.IntersectsWith(pictureBox13.Bounds))
            {
                gameTimer.Stop(); // Останавливаем таймер
                DialogResult result = MessageBox.Show(
                    "Вы испугались и ушли. Вернуться в меню?",
                    "Страх",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);

                if (result == DialogResult.OK)
                {
                    Form1 menu = new Form1();
                    menu.Show();
                    this.Close();
                }
            }

            // После обновления позиции игрока добавим ограничения по экрану

            // Левая граница
            if (pictureBox25.Left < 0)
                pictureBox25.Left = 0;

            // Правая граница (ширина формы минус ширина игрока)
            if (pictureBox25.Right > this.ClientSize.Width)
                pictureBox25.Left = this.ClientSize.Width - pictureBox25.Width;

            // Верхняя граница (чтобы игрок не уходил слишком высоко)
            if (pictureBox25.Top < 0)
            {
                pictureBox25.Top = 0;
                jumpSpeedCurrent = 0;
                jumping = false;
            }

            // Нижняя граница (например, пол формы или можно сделать игровое падение)
            if (pictureBox25.Bottom > this.ClientSize.Height)
            {
                pictureBox25.Top = this.ClientSize.Height - pictureBox25.Height;
                isOnGround = true;
                jumping = false;
                jumpSpeedCurrent = 0;
            }

            isOnGround = false;

            // Проверка столкновений с платформами
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && x.Tag != null && x.Tag.ToString() == "platform")
                {
                    // Проверяем, пересекается ли игрок с платформой
                    if (pictureBox25.Bounds.IntersectsWith(x.Bounds))
                    {
                        // Если игрок падает вниз (не прыгает)
                        if (!jumping && pictureBox25.Bottom <= x.Top + (gravity + 5))
                        {
                            // Устанавливаем игрока на платформу
                            pictureBox25.Top = x.Top - pictureBox25.Height;
                            isOnGround = true;
                            jumpSpeedCurrent = 0;
                        }
                        // Если игрок прыгает и касается платформы снизу (например, ударился головой)
                        else if (jumping && pictureBox25.Top < x.Bottom && pictureBox25.Bottom > x.Bottom)
                        {
                            jumpSpeedCurrent = 0;
                            jumping = false;
                            // Можно установить позицию игрока ниже платформы (чтобы не застрял в ней)
                            pictureBox25.Top = x.Bottom;
                        }
                    }
                }
            }
        }



        private void Form12_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.A)
                goLeft = false;
            if (e.KeyCode == Keys.Right || e.KeyCode == Keys.D)
                goRight = false;
        }

        private void Form12_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.A)
                goLeft = true;
            if (e.KeyCode == Keys.Right || e.KeyCode == Keys.D)
                goRight = true;

            if ((e.KeyCode == Keys.Up || e.KeyCode == Keys.W || e.KeyCode == Keys.Space) && isOnGround)
            {
                jumping = true;
                jumpSpeedCurrent = jumpSpeed;
            }
        }
    }
}
