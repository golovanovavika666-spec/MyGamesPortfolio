﻿namespace _2д_игра
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            pictureBox1 = new PictureBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            panel1 = new Panel();
            button11 = new Button();
            panel2 = new Panel();
            panel3 = new Panel();
            panel4 = new Panel();
            panel5 = new Panel();
            panel6 = new Panel();
            panel7 = new Panel();
            panel8 = new Panel();
            panel9 = new Panel();
            panel10 = new Panel();
            panel11 = new Panel();
            panel12 = new Panel();
            panel13 = new Panel();
            panel14 = new Panel();
            panel15 = new Panel();
            panel16 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(800, 450);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(192, 255, 255);
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = Color.FromArgb(128, 64, 64);
            button1.Location = new Point(29, 36);
            button1.Name = "button1";
            button1.Size = new Size(60, 58);
            button1.TabIndex = 1;
            button1.Text = "1 уровень";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(192, 255, 255);
            button2.FlatStyle = FlatStyle.Flat;
            button2.ForeColor = Color.FromArgb(128, 64, 64);
            button2.Location = new Point(126, 36);
            button2.Name = "button2";
            button2.Size = new Size(60, 58);
            button2.TabIndex = 2;
            button2.Text = "2 уровень";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(192, 255, 255);
            button3.FlatStyle = FlatStyle.Flat;
            button3.ForeColor = Color.FromArgb(128, 64, 64);
            button3.Location = new Point(227, 36);
            button3.Name = "button3";
            button3.Size = new Size(60, 58);
            button3.TabIndex = 3;
            button3.Text = "3 уровень";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(192, 255, 255);
            button4.FlatStyle = FlatStyle.Flat;
            button4.ForeColor = Color.FromArgb(128, 64, 64);
            button4.Location = new Point(29, 133);
            button4.Name = "button4";
            button4.Size = new Size(60, 58);
            button4.TabIndex = 4;
            button4.Text = "4 уровень";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(192, 255, 255);
            button5.FlatStyle = FlatStyle.Flat;
            button5.ForeColor = Color.FromArgb(128, 64, 64);
            button5.Location = new Point(126, 133);
            button5.Name = "button5";
            button5.Size = new Size(60, 58);
            button5.TabIndex = 5;
            button5.Text = "5 уровень";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.BackColor = Color.FromArgb(192, 255, 255);
            button6.FlatStyle = FlatStyle.Flat;
            button6.ForeColor = Color.FromArgb(128, 64, 64);
            button6.Location = new Point(227, 133);
            button6.Name = "button6";
            button6.Size = new Size(60, 58);
            button6.TabIndex = 6;
            button6.Text = "6 уровень";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(192, 255, 255);
            button7.FlatStyle = FlatStyle.Flat;
            button7.ForeColor = Color.FromArgb(128, 64, 64);
            button7.Location = new Point(29, 233);
            button7.Name = "button7";
            button7.Size = new Size(60, 58);
            button7.TabIndex = 7;
            button7.Text = "7 уровень";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.BackColor = Color.FromArgb(192, 255, 255);
            button8.FlatStyle = FlatStyle.Flat;
            button8.ForeColor = Color.FromArgb(128, 64, 64);
            button8.Location = new Point(126, 233);
            button8.Name = "button8";
            button8.Size = new Size(60, 58);
            button8.TabIndex = 8;
            button8.Text = "8 уровень";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.BackColor = Color.FromArgb(192, 255, 255);
            button9.FlatStyle = FlatStyle.Flat;
            button9.ForeColor = Color.FromArgb(128, 64, 64);
            button9.Location = new Point(227, 233);
            button9.Name = "button9";
            button9.Size = new Size(60, 58);
            button9.TabIndex = 9;
            button9.Text = "9 уровень";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.BackColor = Color.FromArgb(192, 255, 255);
            button10.FlatStyle = FlatStyle.Flat;
            button10.ForeColor = Color.FromArgb(128, 64, 64);
            button10.Location = new Point(12, 12);
            button10.Name = "button10";
            button10.Size = new Size(134, 26);
            button10.TabIndex = 10;
            button10.Text = "Выйти в главное меню";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Silver;
            panel1.BackgroundImageLayout = ImageLayout.None;
            panel1.Controls.Add(button11);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button7);
            panel1.Controls.Add(button8);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button9);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button6);
            panel1.Controls.Add(button5);
            panel1.Location = new Point(257, 37);
            panel1.Name = "panel1";
            panel1.Size = new Size(307, 384);
            panel1.TabIndex = 11;
            panel1.Paint += panel1_Paint;
            // 
            // button11
            // 
            button11.BackColor = Color.FromArgb(192, 0, 0);
            button11.FlatStyle = FlatStyle.Flat;
            button11.ForeColor = Color.FromArgb(128, 64, 64);
            button11.Location = new Point(126, 311);
            button11.Name = "button11";
            button11.Size = new Size(60, 58);
            button11.TabIndex = 10;
            button11.Text = "10  БОСС";
            button11.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gray;
            panel2.Location = new Point(203, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(77, 71);
            panel2.TabIndex = 12;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(64, 64, 64);
            panel3.Location = new Point(186, 60);
            panel3.Name = "panel3";
            panel3.Size = new Size(65, 71);
            panel3.TabIndex = 13;
            // 
            // panel4
            // 
            panel4.BackColor = Color.DimGray;
            panel4.Location = new Point(237, 73);
            panel4.Name = "panel4";
            panel4.Size = new Size(40, 55);
            panel4.TabIndex = 13;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(64, 64, 64);
            panel5.Location = new Point(203, 122);
            panel5.Name = "panel5";
            panel5.Size = new Size(77, 83);
            panel5.TabIndex = 14;
            // 
            // panel6
            // 
            panel6.BackColor = Color.DimGray;
            panel6.Location = new Point(271, 27);
            panel6.Name = "panel6";
            panel6.Size = new Size(61, 30);
            panel6.TabIndex = 15;
            // 
            // panel7
            // 
            panel7.BackColor = Color.FromArgb(64, 64, 64);
            panel7.Location = new Point(533, 334);
            panel7.Name = "panel7";
            panel7.Size = new Size(114, 104);
            panel7.TabIndex = 16;
            // 
            // panel8
            // 
            panel8.BackColor = Color.Gray;
            panel8.Location = new Point(570, 303);
            panel8.Name = "panel8";
            panel8.Size = new Size(77, 71);
            panel8.TabIndex = 13;
            // 
            // panel9
            // 
            panel9.BackColor = Color.DimGray;
            panel9.Location = new Point(550, 283);
            panel9.Name = "panel9";
            panel9.Size = new Size(52, 67);
            panel9.TabIndex = 17;
            // 
            // panel10
            // 
            panel10.BackColor = Color.DimGray;
            panel10.Location = new Point(458, 397);
            panel10.Name = "panel10";
            panel10.Size = new Size(118, 100);
            panel10.TabIndex = 18;
            // 
            // panel11
            // 
            panel11.BackColor = Color.Gray;
            panel11.Location = new Point(0, 348);
            panel11.Name = "panel11";
            panel11.Size = new Size(103, 102);
            panel11.TabIndex = 19;
            // 
            // panel12
            // 
            panel12.BackColor = Color.FromArgb(64, 64, 64);
            panel12.Location = new Point(79, 379);
            panel12.Name = "panel12";
            panel12.Size = new Size(107, 71);
            panel12.TabIndex = 20;
            // 
            // panel13
            // 
            panel13.BackColor = Color.DimGray;
            panel13.Location = new Point(0, 303);
            panel13.Name = "panel13";
            panel13.Size = new Size(61, 60);
            panel13.TabIndex = 21;
            // 
            // panel14
            // 
            panel14.BackColor = Color.FromArgb(64, 64, 64);
            panel14.Location = new Point(693, 0);
            panel14.Name = "panel14";
            panel14.Size = new Size(107, 71);
            panel14.TabIndex = 22;
            // 
            // panel15
            // 
            panel15.BackColor = Color.DimGray;
            panel15.Location = new Point(580, 0);
            panel15.Name = "panel15";
            panel15.Size = new Size(140, 38);
            panel15.TabIndex = 23;
            // 
            // panel16
            // 
            panel16.BackColor = Color.Gray;
            panel16.Location = new Point(742, 48);
            panel16.Name = "panel16";
            panel16.Size = new Size(76, 80);
            panel16.TabIndex = 24;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel16);
            Controls.Add(panel15);
            Controls.Add(panel14);
            Controls.Add(panel13);
            Controls.Add(panel12);
            Controls.Add(panel11);
            Controls.Add(panel10);
            Controls.Add(panel9);
            Controls.Add(panel8);
            Controls.Add(panel7);
            Controls.Add(panel6);
            Controls.Add(panel5);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(button10);
            Controls.Add(pictureBox1);
            Name = "Form2";
            Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Panel panel1;
        private Button button11;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private Panel panel6;
        private Panel panel9;
        private Panel panel7;
        private Panel panel8;
        private Panel panel10;
        private Panel panel11;
        private Panel panel12;
        private Panel panel13;
        private Panel panel14;
        private Panel panel15;
        private Panel panel16;
    }
}