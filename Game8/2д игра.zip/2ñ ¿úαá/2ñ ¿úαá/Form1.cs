using System.Media;

namespace _2д_игра
{
    public partial class Form1 : Form
    {
        SoundPlayer musicPlayer = new SoundPlayer("Gearsy Septima - Platformer (online-audio-converter.com).wav");
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            musicPlayer.PlayLooping(); // Запуск музыки по кругу
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form7 f7 = new Form7();
            f7.Show();
            Hide();
        }
    }
}
