﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace _2д_игра
{
    public partial class Form3 : Form
    {
        // Управление движением
        bool goLeft, goRight, jumping;
        int jumpSpeed = 20;
        int jumpSpeedCurrent;
        int gravity = 10;
        bool isOnGround;
        Point playerStartPoint;
        int lives = 5; // количество жизней
        Label livesLabel = new Label(); // лейбл для отображения жизней
        List<PictureBox> spikes = new List<PictureBox>(); // список шипов

        System.Windows.Forms.Timer gameTimer = new System.Windows.Forms.Timer();
        public Form3()
        {
            InitializeComponent();
            Point playerStartPoint;
            playerStartPoint = pictureBox11.Location; // Запоминаем стартовую позицию игрока

            // Настраиваем таймер
            gameTimer.Interval = 20; // 20 мс - примерно 50 кадров в секунду
            gameTimer.Tick += gameTimer_Tick;
            gameTimer.Start();

            this.KeyDown += Form3_KeyDown;
            this.KeyUp += Form3_KeyUp;

            // Устанавливаем Tag "platform" для земли (8 платформ)
            pictureBox2.Tag = "platform";
            pictureBox3.Tag = "platform";
            pictureBox4.Tag = "platform";
            pictureBox5.Tag = "platform";
            pictureBox6.Tag = "platform";
            pictureBox7.Tag = "platform";
            pictureBox8.Tag = "platform";
            pictureBox9.Tag = "nextLevel";
            pictureBox10.Tag = "exitScared";


            // Лейбл для жизней
            label1.Text = "Жизни: " + lives;
            livesLabel.Font = new Font("Arial", 14, FontStyle.Bold);
            livesLabel.ForeColor = Color.Red;
            livesLabel.BackColor = Color.Transparent;
            livesLabel.AutoSize = true;
            livesLabel.Location = new Point(10, 10);
            this.Controls.Add(livesLabel);

            // Назначаем шипам тег и добавляем их в список
            pictureBox12.Tag = "spike";
            pictureBox13.Tag = "spike";
            pictureBox14.Tag = "spike";

            spikes.Add(pictureBox12);
            spikes.Add(pictureBox13);
            spikes.Add(pictureBox14);

            // Важно: на форме у тебя уже должны быть добавлены pictureBox1..pictureBox11
            // 11 - игрок

        }

        private void gameTimer_Tick(object sender, EventArgs e)
        {
            // Движение влево-вправо
            if (goLeft)
                pictureBox11.Left -= 7;
            if (goRight)
                pictureBox11.Left += 7;

            // Прыжок или падение
            if (jumping)
            {
                // Прыжок вверх
                pictureBox11.Top -= jumpSpeedCurrent;
                jumpSpeedCurrent -= 1; // уменьшение скорости прыжка (гравитация)
                if (jumpSpeedCurrent < 0)
                    jumping = false; // начинается падение после пика прыжка
            }
            else
            {
                // Падение вниз (гравитация)
                pictureBox11.Top += gravity;
            }


            foreach (PictureBox spike in spikes)
            {
                if (pictureBox11.Bounds.IntersectsWith(spike.Bounds))
                {
                    lives--;
                    label1.Text = "Жизни: " + lives;
                    pictureBox11.Location = playerStartPoint;

                    if (lives <= 0)
                    {
                        gameTimer.Stop();
                        MessageBox.Show("Вы проиграли! Жизней не осталось.");
                        Form1 menu = new Form1();
                        menu.Show();
                        this.Close();
                    }

                    break; // чтобы жизнь не снялась несколько раз за один тик
                }
            }

            // Проверка перехода на следующий уровень
            if (pictureBox11.Bounds.IntersectsWith(pictureBox9.Bounds))
            {
                gameTimer.Stop(); // Останавливаем таймер
                DialogResult result = MessageBox.Show(
                    "Вы дошли до конца уровня! Что дальше?",
                    "Выбор",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    this.Hide();
                    Form4 form4 = new Form4();
                    form4.Show();
                }
                else if (result == DialogResult.No)
                {
                    // Вернуться в меню
                    Form1 menu = new Form1();
                    menu.Show();
                    this.Close();
                }
            }

            // Проверка выхода в страхе
            if (pictureBox11.Bounds.IntersectsWith(pictureBox10.Bounds))
            {
                gameTimer.Stop(); // Останавливаем таймер
                DialogResult result = MessageBox.Show(
                    "Вы испугались и ушли. Вернуться в меню?",
                    "Страх",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);

                if (result == DialogResult.OK)
                {
                    Form1 menu = new Form1();
                    menu.Show();
                    this.Close();
                }
            }

            // После обновления позиции игрока добавим ограничения по экрану

            // Левая граница
            if (pictureBox11.Left < 0)
                pictureBox11.Left = 0;

            // Правая граница (ширина формы минус ширина игрока)
            if (pictureBox11.Right > this.ClientSize.Width)
                pictureBox11.Left = this.ClientSize.Width - pictureBox11.Width;

            // Верхняя граница (чтобы игрок не уходил слишком высоко)
            if (pictureBox11.Top < 0)
            {
                pictureBox11.Top = 0;
                jumpSpeedCurrent = 0;
                jumping = false;
            }

            // Нижняя граница (например, пол формы или можно сделать игровое падение)
            if (pictureBox11.Bottom > this.ClientSize.Height)
            {
                pictureBox11.Top = this.ClientSize.Height - pictureBox11.Height;
                isOnGround = true;
                jumping = false;
                jumpSpeedCurrent = 0;
            }

            isOnGround = false;

            // Проверка столкновений с платформами
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && x.Tag != null && x.Tag.ToString() == "platform")
                {
                    // Проверяем, пересекается ли игрок с платформой
                    if (pictureBox11.Bounds.IntersectsWith(x.Bounds))
                    {
                        // Если игрок падает вниз (не прыгает)
                        if (!jumping && pictureBox11.Bottom <= x.Top + (gravity + 5))
                        {
                            // Устанавливаем игрока на платформу
                            pictureBox11.Top = x.Top - pictureBox11.Height;
                            isOnGround = true;
                            jumpSpeedCurrent = 0;
                        }
                        // Если игрок прыгает и касается платформы снизу (например, ударился головой)
                        else if (jumping && pictureBox11.Top < x.Bottom && pictureBox11.Bottom > x.Bottom)
                        {
                            jumpSpeedCurrent = 0;
                            jumping = false;
                            // Можно установить позицию игрока ниже платформы (чтобы не застрял в ней)
                            pictureBox11.Top = x.Bottom;
                        }
                    }
                }
            }
        }

        private void Form3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.A)
                goLeft = true;
            if (e.KeyCode == Keys.Right || e.KeyCode == Keys.D)
                goRight = true;

            if ((e.KeyCode == Keys.Up || e.KeyCode == Keys.W || e.KeyCode == Keys.Space) && isOnGround)
            {
                jumping = true;
                jumpSpeedCurrent = jumpSpeed;
            }
        }

        private void Form3_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.A)
                goLeft = false;
            if (e.KeyCode == Keys.Right || e.KeyCode == Keys.D)
                goRight = false;
        }
    }
}
