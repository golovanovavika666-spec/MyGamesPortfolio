﻿
namespace кликер1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            button1 = new Button();
            label1 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            pictureBox2 = new PictureBox();
            pictureBoxAnimation = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBoxX5Upgrade = new PictureBox();
            megaUpgradeIcon = new PictureBox();
            megaProgressBar = new ProgressBar();
            megaGifBar = new PictureBox();
            pictureBoxMegaClicker = new PictureBox();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxAnimation).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxX5Upgrade).BeginInit();
            ((System.ComponentModel.ISupportInitialize)megaUpgradeIcon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)megaGifBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxMegaClicker).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(325, 191);
            button1.Name = "button1";
            button1.Size = new Size(132, 45);
            button1.TabIndex = 0;
            button1.Text = "Нажми меня!";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 1;
            label1.Text = "label1";
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(400, 242);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(57, 55);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBoxAnimation
            // 
            pictureBoxAnimation.Location = new Point(633, 12);
            pictureBoxAnimation.Name = "pictureBoxAnimation";
            pictureBoxAnimation.Size = new Size(155, 162);
            pictureBoxAnimation.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxAnimation.TabIndex = 6;
            pictureBoxAnimation.TabStop = false;
            pictureBoxAnimation.Visible = false;
            pictureBoxAnimation.Click += pictureBox1_Click_1;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(480, 244);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(57, 53);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 5;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(325, 242);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(57, 55);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 7;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(250, 242);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(57, 55);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 8;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(552, 242);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(57, 55);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 9;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(0, 0);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(26, 450);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 10;
            pictureBox7.TabStop = false;
            pictureBox7.Visible = false;
            pictureBox7.Click += pictureBox7_Click;
            // 
            // pictureBoxX5Upgrade
            // 
            pictureBoxX5Upgrade.Location = new Point(12, 180);
            pictureBoxX5Upgrade.Name = "pictureBoxX5Upgrade";
            pictureBoxX5Upgrade.Size = new Size(155, 183);
            pictureBoxX5Upgrade.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxX5Upgrade.TabIndex = 11;
            pictureBoxX5Upgrade.TabStop = false;
            // 
            // megaUpgradeIcon
            // 
            megaUpgradeIcon.Location = new Point(791, 0);
            megaUpgradeIcon.Name = "megaUpgradeIcon";
            megaUpgradeIcon.Size = new Size(10, 10);
            megaUpgradeIcon.SizeMode = PictureBoxSizeMode.StretchImage;
            megaUpgradeIcon.TabIndex = 12;
            megaUpgradeIcon.TabStop = false;
            megaUpgradeIcon.Visible = false;
            megaUpgradeIcon.Click += megaUpgradeIcon_Click_1;
            // 
            // megaProgressBar
            // 
            megaProgressBar.Location = new Point(225, 75);
            megaProgressBar.Maximum = 1000000;
            megaProgressBar.Name = "megaProgressBar";
            megaProgressBar.Size = new Size(359, 23);
            megaProgressBar.TabIndex = 13;
            megaProgressBar.Visible = false;
            // 
            // megaGifBar
            // 
            megaGifBar.Image = (Image)resources.GetObject("megaGifBar.Image");
            megaGifBar.Location = new Point(191, 37);
            megaGifBar.Name = "megaGifBar";
            megaGifBar.Size = new Size(418, 27);
            megaGifBar.SizeMode = PictureBoxSizeMode.StretchImage;
            megaGifBar.TabIndex = 14;
            megaGifBar.TabStop = false;
            megaGifBar.Visible = false;
            // 
            // pictureBoxMegaClicker
            // 
            pictureBoxMegaClicker.Image = (Image)resources.GetObject("pictureBoxMegaClicker.Image");
            pictureBoxMegaClicker.Location = new Point(400, 324);
            pictureBoxMegaClicker.Name = "pictureBoxMegaClicker";
            pictureBoxMegaClicker.Size = new Size(57, 55);
            pictureBoxMegaClicker.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxMegaClicker.TabIndex = 15;
            pictureBoxMegaClicker.TabStop = false;
            pictureBoxMegaClicker.Click += pictureBoxMegaClicker_Click_1;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(480, 324);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(57, 55);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 16;
            pictureBox1.TabStop = false;
            pictureBox1.Visible = false;
            pictureBox1.Click += pictureBox1_Click_2;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBoxMegaClicker);
            Controls.Add(megaGifBar);
            Controls.Add(megaProgressBar);
            Controls.Add(megaUpgradeIcon);
            Controls.Add(pictureBoxX5Upgrade);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBoxAnimation);
            Controls.Add(pictureBox2);
            Controls.Add(label1);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxAnimation).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxX5Upgrade).EndInit();
            ((System.ComponentModel.ISupportInitialize)megaUpgradeIcon).EndInit();
            ((System.ComponentModel.ISupportInitialize)megaGifBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxMegaClicker).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private Button button1;
        private Label label1;
        private System.Windows.Forms.Timer timer1;
        private PictureBox pictureBox2;
        private PictureBox pictureBoxAnimation;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private PictureBox pictureBoxX5Upgrade;
        private PictureBox megaUpgradeIcon;
        private ProgressBar megaProgressBar;
        private PictureBox megaGifBar;
        private PictureBox pictureBoxMegaClicker;
        private PictureBox pictureBox1;
    }
}
