using System;
using System.Drawing;
using System.Collections.Generic;
using System.Reflection.Emit;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.IO;
using System.Media;
namespace кликер1
{
    public partial class Form1 : Form
    {
        List<string> backgroundPaths = new List<string>
        {
            "C:\\Users\\RSS\\Pictures\\wp4007968.jpg",
            "C:\\Users\\RSS\\Pictures\\bg2.jpg",
            "C:\\Users\\RSS\\Pictures\\bg3.jpg",
            "C:\\Users\\RSS\\Pictures\\bg4.jpg",
            "C:\\Users\\RSS\\Pictures\\bg5.jpg"
        };

        List<string> catPaths = new List<string>
        {
            "C:\\Users\\RSS\\Pictures\\cat2.gif",
            "C:\\Users\\RSS\\Pictures\\cat3.gif",
            "C:\\Users\\RSS\\Pictures\\cat4.gif",
            "C:\\Users\\RSS\\Pictures\\cat5.gif"
        };

        long x2Count = 0;
        long maxX2Count = 5;
        bool x5Unlocked = false;
        int x5Price = 1000;


        int megaClickerPrice = 1_000_000;
        int megaClickerTimeLeft = 120; 
        bool isMegaClickerActive = false;
        System.Windows.Forms.Timer megaTimer = new System.Windows.Forms.Timer();





        int megaUpgradePrice = 100_000_000;
        bool megaUpgradeBought = false;
        int clicksSinceLastReward = 0;


        int flyingCatPurchases = 0;
        bool x5UpgradeAvailable = false;
        bool x5UpgradeBought = false;
        PictureBox x5UpgradeIcon;
        PictureBox x5CatAnimation;
        int backgroundIndex = 0;
        int catIndex = 0;
        int backgroundPrice = 5000;
        bool animationBought = false;
        int catLevel = 0;
        int clicks = 0;
        int autoClickers = 0;
        int autoClickerPrice = 50;

        
        int thunderUpgradePrice = 2_000_000;
        bool thunderUpgradeBought = false;
        SoundPlayer thunderSound;
        
        

        int clickPower = 1;
        int x2Price = 30;

        int critPrice = 100;
        bool critActive = false;
        Random random = new Random();

        int rainPrice = 200;
        bool rainActive = false;

        System.Windows.Forms.Timer rainTimer = new System.Windows.Forms.Timer();
        List<PictureBox> rainDrops = new List<PictureBox>();
        Random rand = new Random();

        bool autoClicker2Active = false; 
        System.Windows.Forms.Timer autoClicker2Timer = new System.Windows.Forms.Timer();
        int clickCount = 0; 

        System.Windows.Forms.Timer critTimer = new System.Windows.Forms.Timer();

        List<PictureBox> flyingX2s = new List<PictureBox>();
        List<Point> flyingSpeeds = new List<Point>();
        System.Windows.Forms.Timer flyTimer = new System.Windows.Forms.Timer();
        System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        public Form1()
        {
            InitializeComponent();
            
            timer.Interval = 1000;
            timer.Tick += Timer_Tick;

            
            button1.Click += button1_Click_1;

            
            pictureBox2.Click += pictureBox2_Click;

            UpdateLabel();

            
            flyTimer.Interval = 30;
            flyTimer.Tick += FlyTimer_Tick;
            flyTimer.Start();

            
            pictureBox3.Click += pictureBox3_Click;


            pictureBox4.Click += pictureBox4_Click;

            
            critTimer.Interval = 2000; 
            critTimer.Tick += CritTimer_Tick;

            pictureBox5.Click += pictureBox5_Click;

            rainTimer.Interval = 50;
            rainTimer.Tick += RainTimer_Tick;

            autoClicker2Timer.Interval = 1000; 
            autoClicker2Timer.Tick += AutoClicker2Timer_Tick;
            pictureBoxX5Upgrade.Click += PictureBoxX5Upgrade_Click;

        }





        private string FormatNumber(long number)
        {
            if (number >= 1_000_000_000_000) return (number / 1_000_000_000_000D).ToString("0.##") + "T";
            if (number >= 1_000_000_000) return (number / 1_000_000_000D).ToString("0.##") + "B";
            if (number >= 1_000_000) return (number / 1_000_000D).ToString("0.##") + "M";
            if (number >= 1_000) return (number / 1_000D).ToString("0.##") + "K";
            return number.ToString();
        }
        private void PictureBoxX5Upgrade_Click(object sender, EventArgs e)
        {
            if (clicks >= x5Price)
            {
                clicks -= x5Price;
                clickPower *= 5; 
                x5Price += 2000; 

                
                if (!x5UpgradeBought)
                {
                    x5UpgradeBought = true;

                    x5CatAnimation = new PictureBox();
                    x5CatAnimation.Image = Image.FromFile("C:\\Users\\RSS\\Pictures\\x5CatAnimation55.gif"); 
                    x5CatAnimation.SizeMode = PictureBoxSizeMode.Zoom;
                    x5CatAnimation.BackColor = Color.Transparent;
                    x5CatAnimation.Size = new Size(150, 150);
                    x5CatAnimation.Location = new Point(this.ClientSize.Width - 160, this.ClientSize.Height - 160);
                    x5CatAnimation.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;

                    this.Controls.Add(x5CatAnimation);
                    x5CatAnimation.BringToFront();
                }

                MessageBox.Show("Куплен X5 бонус! Клики увеличены!");
                UpdateLabel();
            }
            else
            {
                MessageBox.Show($"Нужно {x5Price} кликов для следующей покупки X5!");
            }
        }
        private void CheckX5UpgradeAvailability()
        {
            if (flyingCatPurchases >= 5 && !x5UpgradeAvailable)
            {
                x5UpgradeAvailable = true;
                pictureBoxX5Upgrade.Visible = true;
                pictureBoxX5Upgrade.Image = Image.FromFile("C:\\Users\\RSS\\Pictures\\x5icon.png"); 
                pictureBoxX5Upgrade.SizeMode = PictureBoxSizeMode.Zoom;
                pictureBoxX5Upgrade.BackColor = Color.Transparent;
                MessageBox.Show("Открыт новый апгрейд: x5 кот!");
            }
        }
        private void FlyTimer_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < flyingX2s.Count; i++)
            {
                PictureBox pb = flyingX2s[i];
                Point speed = flyingSpeeds[i];

                pb.Left += speed.X;
                pb.Top += speed.Y;

                
                if (pb.Right >= this.ClientSize.Width || pb.Left <= 0)
                    flyingSpeeds[i] = new Point(-speed.X, speed.Y);

                if (pb.Bottom >= this.ClientSize.Height || pb.Top <= 0)
                    flyingSpeeds[i] = new Point(speed.X, -speed.Y);
            }
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            clicks += autoClickers;
            clicks += clickPower;
            UpdateLabel();
        }
        private void UpdateLabel()
        {
            label1.Text = $"Клики: {FormatNumber(clicks)}\n" +
                          $"Автокликеры: {FormatNumber(autoClickers)}\n" +
                          $"Цена автокликера: {FormatNumber(autoClickerPrice)}\n" +
                          $"Сила клика: {FormatNumber(clickPower)}\n" +
                          $"Цена X2: {FormatNumber(x2Price)}\n" +
                          $"Цена Крит-удара: {FormatNumber(critPrice)}\n" +
                          $"Цена Дождя: {FormatNumber(rainPrice)}";
            if (clicks >= 1_000_000 && !megaUpgradeBought)
            {
                megaUpgradeIcon.Visible = true;
            }

            if (clicks >= 1_000_000 && !pictureBoxMegaClicker.Visible)
            {
                pictureBoxMegaClicker.Visible = true;
            }
        }




        private void megaUpgradeIcon_Click(object sender, EventArgs e)
        {
            if (clicks >= megaUpgradePrice)
            {
                clicks -= megaUpgradePrice;
                megaUpgradeBought = true;
                megaUpgradeIcon.Visible = false;
                megaUpgradeIcon.Enabled = false;
                megaProgressBar.Visible = true;
                clicksSinceLastReward = 0;
            }
            else
            {
                MessageBox.Show("Нужно 100 000 000 кликов для покупки улучшения!");
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            clicks += clickPower;

            if (megaUpgradeBought)
            {
                clicksSinceLastReward += clickPower;
                if (clicksSinceLastReward >= 1_000_000)
                {
                    clicks += 5000;
                    clicksSinceLastReward = 0;
                    megaProgressBar.Value = 0;
                }
                else
                {
                    megaProgressBar.Value = Math.Min(clicksSinceLastReward, 1_000_000);
                }
            }
            if (clicks >= 2_000_000 && !thunderUpgradeBought)
                pictureBox1.Visible = true;

            UpdateLabel();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (clicks >= autoClickerPrice)
            {
                clicks -= autoClickerPrice;
                autoClickers++;
                autoClickerPrice += 25;
                if (!timer.Enabled)
                    timer.Start();
                MessageBox.Show("Куплен автокликер!");
            }
            else
            {
                MessageBox.Show($"Нужно {autoClickerPrice} кликов для покупки автокликера!");
            }

            UpdateLabel();
        }

        private void pictureBoxMegaClicker_Click(object sender, EventArgs e)
        {
            if (clicks >= megaClickerPrice)
            {
                clicks -= megaClickerPrice;
                megaClickerPrice += 2_000_000;

                isMegaClickerActive = true;
                megaClickerTimeLeft = 120; 
                megaGifBar.Visible = true;

                megaTimer.Start();
                UpdateLabel();
                MessageBox.Show("Мега апгрейд активирован! +1000 кликов/сек на 2 минуты");
            }
            else
            {
                MessageBox.Show($"Нужно {megaClickerPrice} кликов для покупки апгрейда.");
            }
        }
        private void MegaTimer_Tick(object sender, EventArgs e)
        {
            if (isMegaClickerActive)
            {
                clicks += 1000;
                megaClickerTimeLeft--;

                if (megaClickerTimeLeft <= 0)
                {
                    isMegaClickerActive = false;
                    megaTimer.Stop();
                    megaGifBar.Visible = false;
                }

                UpdateLabel();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            megaUpgradeIcon.Visible = false;
            megaProgressBar.Visible = false;

            pictureBoxMegaClicker.Visible = false;
            megaGifBar.Visible = false;
            megaTimer.Interval = 1000;
            megaTimer.Tick += MegaTimer_Tick;
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (flyingCatPurchases >= 5)
            {
                MessageBox.Show("Ты уже купила максимум котиков (5/5)!");
                return;
            }

            if (clicks >= x2Price)
            {
                clicks -= x2Price;
                clickPower += 1;
                x2Price += 30;

                
                PictureBox pb = new PictureBox();
                pb.Size = pictureBox3.Size;
                pb.Image = pictureBox3.Image;
                pb.SizeMode = PictureBoxSizeMode.Zoom;
                pb.BackColor = Color.Transparent;

                Random rnd = new Random();
                pb.Left = rnd.Next(0, this.ClientSize.Width - pb.Width);
                pb.Top = rnd.Next(0, this.ClientSize.Height - pb.Height);

                this.Controls.Add(pb);
                pb.BringToFront();

                flyingX2s.Add(pb);
                flyingSpeeds.Add(new Point(rnd.Next(2, 5), rnd.Next(2, 5)));

                flyingCatPurchases++; 

                MessageBox.Show("Куплено X2 улучшение!");
                UpdateLabel();
            }
            else
            {
                MessageBox.Show($"Нужно {x2Price} кликов для покупки X2!");
            }
            CheckX5UpgradeAvailability();
        }
        private void RainTimer_Tick(object sender, EventArgs e)
        {
            // Создаем каплю
            PictureBox drop = new PictureBox();
            drop.Size = new Size(5, 10);
            drop.BackColor = Color.LightBlue;
            drop.Location = new Point(rand.Next(0, this.ClientSize.Width), 0);

            this.Controls.Add(drop);
            rainDrops.Add(drop);

            drop.BringToFront(); // 💡 Вот это важно — капля всегда поверх фона!

            // Обновляем существующие капли
            for (int i = rainDrops.Count - 1; i >= 0; i--)
            {
                rainDrops[i].Top += 10;

                if (rainDrops[i].Top > this.ClientSize.Height)
                {
                    this.Controls.Remove(rainDrops[i]);
                    rainDrops.RemoveAt(i);
                }
            }
        }
        private void CritTimer_Tick(object sender, EventArgs e)
        {
            if (critActive)
            {
                int chance = random.Next(1, 101); // от 1 до 100

                if (chance <= 10) // 10% шанс
                {
                    int bonus = 50; // или random.Next(30, 100);
                    clicks += bonus;
                    MessageBox.Show($"Критический удар! +{bonus} кликов!");
                    UpdateLabel();
                }
            }
        }
        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (clicks >= critPrice)
            {
                clicks -= critPrice;
                critPrice += 100;

                critActive = true;
                critTimer.Start();

                MessageBox.Show("Куплен крит-удар! Шанс 10% раз в 2 секунды!");
                UpdateLabel();
            }
            else
            {
                MessageBox.Show($"Нужно {critPrice} кликов для критического удара!");
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (clicks >= rainPrice)
            {
                clicks -= rainPrice;
                rainPrice += 150;
                clickPower = 3; // x3 клики
                rainActive = true;

                rainTimer.Start();

                MessageBox.Show("Куплен дождь! Теперь клики x3 и идет дождь!");
                UpdateLabel();
            }
            else
            {
                MessageBox.Show($"Нужно {rainPrice} кликов для дождя!");
            }
        }

        private void AutoClicker2Timer_Tick(object sender, EventArgs e)
        {
            if (autoClicker2Active)
            {
                clickCount += 20; // +20 кликов каждую секунду
                label1.Text = "Клики: " + clickCount;
            }
        }

        private async void pictureBox6_Click(object sender, EventArgs e)
        {
            if (!animationBought)
            {
                if (clicks >= backgroundPrice)
                {
                    clicks -= backgroundPrice;
                    animationBought = true;

                    try
                    {
                        // Загружаем котика (первую анимацию)
                        Image gif = null;
                        await Task.Run(() => gif = Image.FromFile("C:\\Users\\RSS\\Pictures\\cat_dance.gif"));

                        pictureBoxAnimation.Invoke(new Action(() =>
                        {
                            pictureBoxAnimation.Image = gif;
                            pictureBoxAnimation.SizeMode = PictureBoxSizeMode.Zoom;
                            pictureBoxAnimation.Visible = true;
                        }));
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка загрузки котика: " + ex.Message);
                        return;
                    }

                    // Загружаем следующую картинку котика (иконка на кнопке)
                    if (catIndex < catPaths.Count)
                    {
                        try
                        {
                            Image catImg = null;
                            await Task.Run(() => catImg = Image.FromFile(catPaths[catIndex]));
                            pictureBox6.Image = catImg;
                            catIndex++;
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Ошибка загрузки иконки кота: " + ex.Message);
                        }
                    }

                    MessageBox.Show("Котик активирован!");
                    UpdateLabel();
                }
                else
                {
                    MessageBox.Show($"Нужно {backgroundPrice} кликов для активации котика!");
                }
            }
            else
            {
                if (clicks >= backgroundPrice)
                {
                    clicks -= backgroundPrice;
                    backgroundPrice += 2000;

                    try
                    {
                        Image newBg = null;
                        Image newCat = null;

                        // Загружаем в фоне и делаем копию
                        await Task.Run(() =>
                        {
                            if (backgroundIndex < backgroundPaths.Count)
                            {
                                using (var temp = Image.FromFile(backgroundPaths[backgroundIndex]))
                                {
                                    newBg = new Bitmap(temp); // Копия в памяти
                                }
                            }

                            if (catIndex < catPaths.Count)
                            {
                                using (var temp = Image.FromFile(catPaths[catIndex]))
                                {
                                    newCat = new Bitmap(temp); // Копия в памяти
                                }
                            }
                        });

                        // Применяем в UI-потоке
                        if (newBg != null)
                        {
                            this.BackgroundImage = newBg;
                            this.BackgroundImageLayout = ImageLayout.Stretch;
                            backgroundIndex++;
                        }

                        if (newCat != null)
                        {
                            pictureBox6.Image = newCat;
                            catIndex++;
                        }

                        MessageBox.Show("Фон куплен!");
                        UpdateLabel();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка загрузки фона или кота: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show($"Нужно {backgroundPrice} кликов для покупки фона!");
                }
            }
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void megaUpgradeIcon_Click_1(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (megaClickerTimeLeft > 0)
            {
                clicks += 1000;
                megaClickerTimeLeft--;
                UpdateLabel();
            }
            else
            {
                timer1.Stop();
                megaGifBar.Visible = false;
                isMegaClickerActive = false;
            }
        }

        private void pictureBoxMegaClicker_Click_1(object sender, EventArgs e)
        {
            if (clicks >= megaClickerPrice)
            {
                clicks -= megaClickerPrice;
                megaClickerPrice += 2_000_000;

                isMegaClickerActive = true;
                megaClickerTimeLeft = 120; // снова 2 минуты
                megaGifBar.Visible = true;

                megaTimer.Start();
                UpdateLabel();
                MessageBox.Show("Мега апгрейд активирован! +1000 кликов/сек на 2 минуты");
            }
            else
            {
                MessageBox.Show($"Нужно {megaClickerPrice} кликов для покупки апгрейда.");
            }
        }


        private void PlayThunderSound()
        {
            byte[] soundBytes = Properties.Resources.grom;
            MemoryStream ms = new MemoryStream(soundBytes);
            SoundPlayer player = new SoundPlayer(ms);
            player.Play();
        }

        private void pictureBox1_Click_2(object sender, EventArgs e)
        {
            PlayThunderSound();
        }
    }
}