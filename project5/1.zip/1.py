import pygame
import time

pygame.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Говорящая Свинка")

WHITE = (255, 255, 255)
GRAY = (200, 200, 200)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (173, 216, 230)
DARK_OVERLAY = (0, 0, 0, 150)  # затемнение экрана

# Фон комнат
backgrounds = {
    "Кухня": pygame.image.load("C:/Users/RSS/Pictures/8926ffe363f97885f4b74ca64dfc0829.jpg"),
    "Спальня": pygame.image.load("C:/Users/RSS/Pictures/16878eb0253dcb769d6f010c2be88c76.jpg"),
    "Туалет": pygame.image.load("C:/Users/RSS/Pictures/img-1396318.jpg"),
    "Двор": pygame.image.load("C:/Users/RSS/Pictures/498f6a60c1c0847048040df14870c54e.jpg")
}
for key in backgrounds:
    backgrounds[key] = pygame.transform.scale(backgrounds[key], (WIDTH, HEIGHT))

# Свинка
pig_rect = pygame.Rect(300, 200, 200, 200)
pig_img = pygame.image.load("C:/Users/RSS/Pictures/image-fotor-bg-remover-2025030211144piiig.png")
pig_img = pygame.transform.scale(pig_img, (200, 200))

# Продукты
food_images = [
    pygame.transform.scale(pygame.image.load("C:/Users/RSS/Pictures/204ad2c84e776d4b41163caa13cdbfa8-fotor-bg-remover-2025030117121.png"), (50, 50)),
    pygame.transform.scale(pygame.image.load("C:/Users/RSS/Pictures/100063960341b0-fotor-bg-remover-20250301172740.png"), (50, 50)),
    pygame.transform.scale(pygame.image.load("C:/Users/RSS/Pictures/1600-fotor-bg-remover-20250301172856.png"), (50, 50))
]
food_positions = [(700, 150), (700, 250), (700, 350)]
food_available = [True, True, True]
food_values = [50, 35, 100]

# Метла
broom_img = pygame.image.load("C:/Users/RSS/Pictures/venik-sorgo-malenkiy-11-500x500-fotor-bg-remover-20250302114726метла.png")
broom_img = pygame.transform.scale(broom_img, (80, 80))
broom_position = (600, 300)
broom_dragging = False

# Губка
sponge_img = pygame.Surface((60, 60))
sponge_img.fill((255, 255, 0))  # Жёлтая губка
sponge_position = (600, 400)
sponge_dragging = False

# Лампа
lamp_img = pygame.image.load("C:/Users/RSS/Pictures/6201d8a523ffe44a24b9b8a3bd366265-fotor-bg-remover-20250428232226.png")  # <-- сюда подставь свою лампу
lamp_img = pygame.transform.scale(lamp_img, (80, 80))
lamp_position = (590, 300)
lamp_rect = pygame.Rect(lamp_position[0], lamp_position[1], 80, 80)

# Кнопки
font = pygame.font.Font(None, 36)
buttons = {
    "Кухня": pygame.Rect(50, 500, 150, 50),
    "Спальня": pygame.Rect(250, 500, 150, 50),
    "Туалет": pygame.Rect(450, 500, 150, 50),
    "Двор": pygame.Rect(650, 500, 150, 50),
    "Магазин": pygame.Rect(650, 20, 120, 40)
}

# Потребности
needs = {"Еда": 100, "Туалет": 100, "Сон": 100, "Игры": 100}
hunger_decrease_rate = 100 / (3 * 60)
toilet_decrease_rate = 100 / (10 * 60)
sleep_decrease_rate = 100 / (10 * 60)  # 10 минут на полное истощение
sleep_restore_rate = 100 / (1 * 60)    # 1 минута на полное восстановление

# Переменные
shop_open = False
current_room = "Кухня"
dragging = None
sleeping = False
time_last_eat = time.time()
time_last_toilet = time.time()
time_last_sleep = time.time()

running = True

while running:
    screen.blit(backgrounds[current_room], (0, 0))
    screen.blit(pig_img, pig_rect.topleft)

    now = time.time()

    # Обновление голода
    needs["Еда"] -= (now - time_last_eat) * hunger_decrease_rate
    needs["Еда"] = max(0, needs["Еда"])
    time_last_eat = now

    # Обновление туалета
    needs["Туалет"] -= (now - time_last_toilet) * toilet_decrease_rate
    needs["Туалет"] = max(0, needs["Туалет"])
    time_last_toilet = now

    # Обновление сна
    if sleeping:
        needs["Сон"] += (now - time_last_sleep) * sleep_restore_rate
        needs["Сон"] = min(100, needs["Сон"])
    else:
        needs["Сон"] -= (now - time_last_sleep) * sleep_decrease_rate
        needs["Сон"] = max(0, needs["Сон"])
    time_last_sleep = now

    # Отображение потребностей
    for i, (need, value) in enumerate(needs.items()):
        pygame.draw.rect(screen, RED, (200, 50 + i * 30, 400, 20))
        pygame.draw.rect(screen, GREEN, (200, 50 + i * 30, int(4 * value), 20))
        screen.blit(font.render(need, True, (0, 0, 0)), (100, 50 + i * 30))

    # Отображение еды
    if current_room == "Кухня":
        for i in range(len(food_images)):
            if food_available[i]:
                screen.blit(food_images[i], food_positions[i])

    # Отображение метлы и губки в туалете
    if current_room == "Туалет":
        screen.blit(broom_img, broom_position)
        screen.blit(sponge_img, sponge_position)

    # Отображение лампы в спальне
    if current_room == "Спальня" and not shop_open:
        screen.blit(lamp_img, lamp_position)

    # Затемнение и "спит" надпись
    if sleeping and current_room == "Спальня":
        dark_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        dark_surface.fill(DARK_OVERLAY)
        screen.blit(dark_surface, (0, 0))
        zzzz_text = font.render("Zzzz... Zzzz... Zzzz...", True, WHITE)
        screen.blit(zzzz_text, (pig_rect.x + 20, pig_rect.y - 40))

    # Отображение магазина
    if shop_open:
        pygame.draw.rect(screen, BLUE, (150, 50, 500, 500))
        close_button = pygame.Rect(600, 60, 40, 30)
        pygame.draw.rect(screen, RED, close_button)
        screen.blit(font.render("X", True, (255, 255, 255)), (close_button.x + 10, close_button.y + 5))

        for i, food in enumerate(food_images):
            screen.blit(food, (180, 80 + i * 100))
            buy_button = pygame.Rect(250, 80 + i * 100, 100, 40)
            pygame.draw.rect(screen, GREEN, buy_button)
            screen.blit(font.render("Купить", True, (255, 255, 255)), (buy_button.x + 10, buy_button.y + 10))

    # Отображение кнопок
    if not shop_open:
        for name, rect in buttons.items():
            pygame.draw.rect(screen, GRAY, rect)
            text = font.render(name, True, (0, 0, 0))
            screen.blit(text, (rect.x + 10, rect.y + 10))

    pygame.display.flip()

    # Обработка событий
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            x, y = event.pos

            for room, rect in buttons.items():
                if rect.collidepoint(x, y) and not shop_open:
                    if room == "Магазин":
                        shop_open = True
                    else:
                        current_room = room
                        shop_open = False

            if shop_open and 'close_button' in locals() and close_button.collidepoint(x, y):
                shop_open = False

            if shop_open:
                for i in range(len(food_images)):
                    buy_rect = pygame.Rect(250, 80 + i * 100, 100, 40)
                    if buy_rect.collidepoint(x, y):
                        food_available[i] = True

            if current_room == "Кухня":
                for i in range(len(food_positions)):
                    if food_available[i] and pygame.Rect(food_positions[i][0], food_positions[i][1], 50, 50).collidepoint(x, y):
                        dragging = i

            if current_room == "Туалет":
                if pygame.Rect(broom_position[0], broom_position[1], 80, 80).collidepoint(x, y):
                    broom_dragging = True
                if pygame.Rect(sponge_position[0], sponge_position[1], 60, 60).collidepoint(x, y):
                    sponge_dragging = True

            if current_room == "Спальня":
                if lamp_rect.collidepoint(x, y):
                    sleeping = not sleeping  # Переключение сна

        if event.type == pygame.MOUSEBUTTONUP:
            if dragging is not None:
                x, y = event.pos
                if pig_rect.collidepoint(x, y):
                    needs["Еда"] = min(100, needs["Еда"] + food_values[dragging])
                    food_available[dragging] = False
                dragging = None

            broom_dragging = False
            sponge_dragging = False

        if event.type == pygame.MOUSEMOTION:
            if dragging is not None:
                food_positions[dragging] = (event.pos[0] - 25, event.pos[1] - 25)

            if broom_dragging:
                broom_position = (event.pos[0] - 40, event.pos[1] - 40)

            if sponge_dragging:
                sponge_position = (event.pos[0] - 30, event.pos[1] - 30)
                if pig_rect.collidepoint(event.pos):
                    needs["Туалет"] = min(100, needs["Туалет"] + 0.5)

pygame.quit()
